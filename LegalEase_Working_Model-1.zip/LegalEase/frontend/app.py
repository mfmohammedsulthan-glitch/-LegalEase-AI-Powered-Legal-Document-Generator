import streamlit as st
import requests
from backend.formatters.docx_formatter import format_docx
from backend.formatters.pdf_formatter import format_pdf

st.set_page_config(page_title="LegalEase", page_icon="⚖️", layout="centered")

st.title("⚖️ LegalEase")
st.caption("AI-assisted legal document drafting")

API_URL = st.sidebar.text_input("Backend URL", "http://127.0.0.1:8000")

document_type = st.selectbox(
    "Document Type",
    ["Employment Contract", "NDA", "Lease Agreement", "Service Agreement"],
)
parties = st.text_input("Parties Involved", "Company A and Employee B")
terms = st.text_area(
    "Terms & Conditions",
    "Confidentiality; Payment terms; Termination",
)
dates = st.date_input("Effective Date")

if st.button("Generate Document", type="primary"):
    payload = {
        "document_type": document_type,
        "parties": parties,
        "terms": terms,
        "dates": str(dates),
    }
    try:
        with st.spinner("Gemini is drafting your document..."):
            response = requests.post(
                f"{API_URL}/generate", json=payload, timeout=120
            )
        if response.ok:
            st.session_state["doc_text"] = response.json()["document"]
        else:
            try:
                detail = response.json().get("detail", response.text)
            except Exception:
                detail = response.text
            st.error(f"Backend error: {detail}")
    except requests.RequestException as exc:
        st.error(f"Could not connect to backend: {exc}")

if "doc_text" in st.session_state:
    st.subheader("Preview & Edit")
    edited_text = st.text_area(
        "Edit your document",
        value=st.session_state["doc_text"],
        height=500,
    )

    st.download_button(
        "Download TXT",
        edited_text,
        file_name=f"{document_type}.txt",
        mime="text/plain",
    )

    docx_buffer = format_docx(edited_text, document_type)
    st.download_button(
        "Download DOCX",
        docx_buffer.getvalue(),
        file_name=f"{document_type}.docx",
        mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    )

    pdf_buffer = format_pdf(edited_text, document_type)
    st.download_button(
        "Download PDF",
        pdf_buffer.getvalue(),
        file_name=f"{document_type}.pdf",
        mime="application/pdf",
    )

st.divider()
st.caption("Drafting assistance only. Have a qualified legal professional review documents before use.")
