from io import BytesIO
from docx import Document

def format_docx(text: str, doc_type: str) -> BytesIO:
    doc = Document()
    doc.add_heading(doc_type, 0)
    for paragraph in text.split("\n"):
        doc.add_paragraph(paragraph)
    buffer = BytesIO()
    doc.save(buffer)
    buffer.seek(0)
    return buffer
