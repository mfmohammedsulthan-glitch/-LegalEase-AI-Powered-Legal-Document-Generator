from io import BytesIO
from fpdf import FPDF

def format_pdf(text: str, doc_type: str) -> BytesIO:
    pdf = FPDF()
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()
    pdf.set_font("Helvetica", "B", 16)
    pdf.multi_cell(0, 10, doc_type, align="C")
    pdf.ln(4)
    pdf.set_font("Helvetica", size=11)

    # Keep the basic PDF export robust even if Gemini returns Unicode characters.
    safe_text = text.encode("latin-1", "replace").decode("latin-1")
    for paragraph in safe_text.split("\n"):
        pdf.multi_cell(0, 7, paragraph)
        pdf.ln(1)

    data = bytes(pdf.output())
    buffer = BytesIO(data)
    buffer.seek(0)
    return buffer
