import os
from dotenv import load_dotenv
from google import genai

load_dotenv()

class GeminiDocumentGenerator:
    def __init__(self):
        api_key = os.getenv("GEMINI_API_KEY")
        if not api_key:
            raise RuntimeError("GEMINI_API_KEY is missing. Add it to the .env file.")
        self.client = genai.Client(api_key=api_key)
        self.model = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")

    def generate_document(self, document_type, parties, terms, dates):
        prompt = f"""
You are an AI legal-document drafting assistant.
Create a professional draft for the following document.

Document type: {document_type}
Parties: {parties}
Effective date(s): {dates}
Terms and conditions: {terms}

Requirements:
- Use clear headings, numbered clauses, definitions where appropriate,
  obligations, termination/dispute provisions where appropriate, and signature blocks.
- Do not invent names, dates, addresses, money amounts, laws, or facts.
- Use [PLACEHOLDER] when required information is missing.
- Return only the document draft, without commentary.
- Add a short "Legal Review Notice" at the end stating that the draft should
  be reviewed by a qualified legal professional before use.
"""
        response = self.client.models.generate_content(
            model=self.model,
            contents=prompt,
        )
        return response.text or "No document was generated."
