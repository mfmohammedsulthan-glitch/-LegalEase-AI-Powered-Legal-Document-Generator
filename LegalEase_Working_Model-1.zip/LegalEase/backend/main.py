from fastapi import FastAPI
from .routes import router

app = FastAPI(title="LegalEase - AI Legal Document Generator")
app.include_router(router)

@app.get("/")
def home():
    return {"message": "LegalEase API is running"}

@app.get("/health")
def health():
    return {"status": "ok"}
