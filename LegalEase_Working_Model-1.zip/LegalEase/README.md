# LegalEase

A runnable FastAPI + Streamlit + Gemini legal-document drafting demo.

## 1. Setup

Create a virtual environment:

Windows:
```powershell
python -m venv venv
venv\Scripts\activate
```

Install dependencies:
```powershell
pip install -r requirements.txt
```

Copy `.env.example` to `.env` and add your Gemini API key:
```text
GEMINI_API_KEY=your_key_here
GEMINI_MODEL=gemini-2.5-flash
```

## 2. Start the backend

From the LegalEase folder:
```powershell
uvicorn backend.main:app --reload --port 8000
```

Check:
`http://127.0.0.1:8000/health`

## 3. Start the frontend

Open a second terminal in the same LegalEase folder:
```powershell
streamlit run frontend/app.py
```

The Streamlit page will open in your browser.

## 4. Important

This is an AI-assisted drafting demo, not a substitute for legal advice.
Do not use generated text as a final legal document without appropriate review.
